<?php
header("Location: region.php");
?>